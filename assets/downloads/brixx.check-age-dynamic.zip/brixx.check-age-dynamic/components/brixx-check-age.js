// Brixx JSX kids element
const kids_element = (
  <div>
    <h5>[Kids area]</h5>
    <h6>
      <a href="https://www.youtube.com/kids/" target="_blank">
        Go to YouTube for Kids ...
      </a>
    </h6>
  </div>
);

// Brixx JSX teens element
const teens_element = (
  <div>
    <h5>[Teens area]</h5>
    <h6>
      <a href="https://www.youtube.com/kids/" target="_blank">
        Go to YouTube ...
      </a>
    </h6>
  </div>
);

// Create a Brixx default element
Brixx.element = (
  <div>
    <p>HTML element &lt;brixx-check-age&gt; created with Brixx-Script.</p>
    <DecisionTable>
      <ul>
        <li>
          Baby (0 years old) - <i>It's still a baby!</i>
        </li>
        <li>
          Preschool (under 5 years old) - <i>Unfortunately too young!</i>
        </li>
        <li>
          Kids (under 13 years old) -{" "}
          <i>Show [Kids area] in component section!</i>
        </li>
        <li>
          Teens (13 years or older) -{" "}
          <i>Show [Teens area] in component section!</i>
        </li>
      </ul>
      <hr />
      <Output component name={"element"}>
        <i>Decision table component section ...</i>
      </Output>
      <hr />
      <Input name={"age"} type={"number"}>
        <div>Please enter age</div>
        <Field />
      </Input>
      <Output name={"info"}>
        <Field readonly />
      </Output>
      <Rule age={""} priority={30} info={"Please enter a valid age!"} />
      <Rule age={"0"} priority={40} info={"It's is still a baby!"} />
      <Rule age={"< 6"} priority={20} info={"Unfortunately too young!"} />
      <Rule age={">= 13"} element={teens_element} info={""} />
      <Rule age={"< 13"} priority={10} element={kids_element} info={""} />
      <Check button label={"Check age"} />
    </DecisionTable>
  </div>
);

// Register a Brixx HTML-Element <brixx-check-age>
Brixx.registerElement({ name: "check-age" });

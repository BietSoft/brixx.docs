// Set an animal list
const animals = ['Dog', 'Cat', 'Mouse', 'Spider']

// Create a Brixx default element
Brixx.element = (
  <div>
    <h2>Animals Test</h2>
    <ul>
      {
        animals.map((animal) => (
          <li>
            <h3>{animal}</h3>
          </li>
        ))
      }
    </ul>
  </div>
)

// Register the Brixx HTML element <brixx-animal-list>
Brixx.registerElement({ name: 'animal-list' })

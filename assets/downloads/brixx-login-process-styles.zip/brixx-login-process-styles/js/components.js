/**
 * Brixx JSX Components
 *
 * Copyright 2024 The BRIXX.it Authors
 */

/**
 * Message component
 *
 * Creates the brixx message component
 */
const MessageComponent = (
  data,
  message = `${data.mid} is running.`,
  next = true
) => {
  // Get process identifier
  const { tid } = data;

  // Set brixx element
  const element = (
    <div class="container">
      <h2>Login Process</h2>
      <h4>{message}</h4>
      <div class="row">
        <div>
          {next ? (
            <input type="button" id={"btn_" + tid} value={"Next"} />
          ) : null}
        </div>
      </div>
    </div>
  );

  // Render brixx jsx component
  new Brixx().render({ element });

  // Set next process task active
  if (next) {
    // Next button click handler
    document.getElementById("btn_" + tid).addEventListener("click", () => {
      // Set process task done
      BrixxProcessDefinition.process.done({ tid });
    });
  }
};

/**
 * Login component
 *
 * Creates the brixx login component
 */
const LoginComponent = (data) => {
  // Get process identifier
  const { tid } = data;

  // Set brixx element
  const element = (
    <div class="container">
      <h2>Login Process</h2>
      <h4>Authentication</h4>
      <div class="row">
        <div>User:</div>
        <div class="col-12">
          <input type="text" id={"user"} />
        </div>
      </div>
      <div class="row">
        <div>Password:</div>
        <div class="col-1">
          <input type="text" id={"password"} />
        </div>
      </div>
      <div class="row"></div>
      <div class="row">
        <div>
          <input type="button" id={"btn_login"} value={"Login"} />
        </div>
      </div>
    </div>
  );

  // Render brixx jsx component
  new Brixx().render({ element });

  // Login button click handler
  document.getElementById("btn_login").addEventListener("click", () => {
    // Set task store data
    const store = {
      user: document.getElementById("user").value,
      password: document.getElementById("password").value,
    };

    // Set next process task active with store data
    BrixxProcessDefinition.process.task.next({ tid, store });
  });
};

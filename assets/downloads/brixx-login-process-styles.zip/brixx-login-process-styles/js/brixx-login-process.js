/**
 * Brixx HTML-Element
 * <brixx-login-process>
 *
 * Copyright 2024 The BRIXX.it Authors
 */

// Get process identifier
const pid = await BrixxProcessDefinition.getProcessIdentifier();

// Create a Brixx default element
Brixx.element = (
  <ProcessDefinition mid="Process_nehz6cn" pid={pid}>
    <Task mid="Task_0r94slz" action={(data) => LoginComponent(data)}>
      <Gateway
        mid="Gateway_0r8twz8"
        action={(data) =>
          BrixxProcessDefinition.process.done({ gid: data.gid })
        }
      >
        <Task
          mid="Task_1m8u5ed"
          action={(data) =>
            MessageComponent(data, "You have entered the user area!")
          }
        ></Task>
        <Task
          mid="Task_0zs24yh"
          action={(data) =>
            MessageComponent(data, "You have entered the public area!")
          }
        >
          <Event
            mid="Event_12hx5eq"
            action={(data) =>
              MessageComponent(data, "Login Process completed!", false)
            }
          />
        </Task>
      </Gateway>
    </Task>
  </ProcessDefinition>
);

// Register Brixx HTML element
Brixx.registerElement({ name: "login-process" });

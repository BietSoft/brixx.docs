// Get process identifier
const pid = await BrixxProcessDefinition.getProcessIdentifier();

// Message task action callback function
const addMessageElement = (data, message = `${data.mid} is running.`) => {
  const { tid } = data;
  const element = (
    <div>
      <h2>{message}</h2>
      <p />
      <input type="button" id={"btn_" + tid} value={"Next"} />
    </div>
  );
  new Brixx().render({ element });
  document.getElementById("btn_" + tid).addEventListener("click", () => {
    // Set process done
    BrixxProcessDefinition.process.done({ tid });
  });
};

// Login task action callback function
const addLoginElement = (data) => {
  const { tid } = data;
  const element = (
    <div>
      <h2>Authentication</h2>
      <p>
        User: <input type="text" id={"user"} />
      </p>
      <p>
        Password: <input type="text" id={"password"} />
      </p>
      <input type="button" id={"btn_login"} value={"Login"} />
    </div>
  );
  new Brixx().render({ element });
  document.getElementById("btn_login").addEventListener("click", () => {
    // Set next process task active with store data
    const store = {
      user: document.getElementById("user").value,
      password: document.getElementById("password").value,
    };
    BrixxProcessDefinition.process.task.next({ tid, store });
  });
};

// Create a Brixx default element
Brixx.element = (
  <ProcessDefinition mid="Process_nehz6cn" pid={pid}>
    <Task mid="Task_0r94slz" action={(data) => addLoginElement(data)}>
      <Gateway
        mid="Gateway_0r8twz8"
        action={(data) =>
          BrixxProcessDefinition.process.done({ gid: data.gid })
        }
      >
        <Task
          mid="Task_1m8u5ed"
          action={(data) =>
            addMessageElement(data, "You have entered the user area.")
          }
        />
        <Task
          mid="Task_0zs24yh"
          action={(data) =>
            addMessageElement(data, "You have entered the public area.")
          }
        />
      </Gateway>
    </Task>
  </ProcessDefinition>
);

// Register a Brixx HTML-Element <brixx-login-process>
Brixx.registerElement({ name: "login-process" });

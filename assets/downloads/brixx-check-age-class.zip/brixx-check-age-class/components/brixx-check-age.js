// Load the decision table definitions
const DecisionTableDefinition = DecisionTable.load('./brixx_check_age.json')

// Create a Brixx default element

Brixx.element = (
    <div>
        <p>HTML element &lt;brixx-check-age&gt; created with Brixx-Script.</p>
        <DecisionTable definition={DecisionTableDefinition}>
            <ul>
                <li>Baby (0 years old) - <i>It's still a baby!</i></li>
                <li>Preschool (under 5 years old) - <i>Unfortunately too young!</i></li>
                <li>Kids (under 13 years old) - <i>https://www.youtube.com/kids/</i></li>
                <li>Teens (13 years or older) - <i>https://www.youtube.com/</i></li>
            </ul>
            <Input name={"age"} type={"number"}>
                <div>Please enter age</div>
                <Field />
            </Input>
            <Output name={"info"}>
                <Field readonly />
            </Output>
            <Output name={"url"}>
                <Link />
            </Output>
            <Rule age={"< 6"} priority={20} info={"Unfortunately too young!"} />
            <Rule age={">= 13"} url={"https://www.youtube.com/"} />
            <Rule age={"< 13"} priority={10} info={"Internet Safety for Kids"} url={"https://www.youtube.com/kids/"} />
            <Check button label={"Check age"} />
        </DecisionTable>
    </div>
)

// Register a Brixx HTML-Element <brixx-check-age>
Brixx.registerElement({ name: "check-age" });
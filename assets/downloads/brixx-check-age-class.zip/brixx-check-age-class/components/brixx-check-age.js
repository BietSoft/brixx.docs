// Load the decision table definitions
const DecisionTableDefinition = DecisionTable.load('./brixx_check_age.json')

// Create a Brixx default element
Brixx.element = (
    <div>
        <DecisionTable definition={DecisionTableDefinition}>
            <Input name={"age"} type={"number"}>
                <div>Please enter age</div>
                <Field />
            </Input>
            <Output name={"info"}>
                <Field readonly />
            </Output>
            <Output name={"url"}>
                <Link />
            </Output>
            <Rule age={"< 6"} priority={20} info={"Unfortunately too young!"} />
            <Rule age={">= 13"} url={"https://www.youtube.com/"} />
            <Rule age={"< 13"} priority={10} info={"Internet Safety for Kids"} url={"https://www.youtube.com/kids/"} />
            <Check button label={"Check age"} />
        </DecisionTable>
    </div >
)

// Register a Brixx HTML-Element <brixx-check-age>
Brixx.registerElement({ name: "check-age" });
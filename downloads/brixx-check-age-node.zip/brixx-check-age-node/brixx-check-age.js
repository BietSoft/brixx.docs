// Imports
const BrixxDecisionTable = require("@brixx/decision-script/node").default;

/**
 *  Set the decision table input data list to check
 *  represents e.g. data from a web service or a database
 */
const input_data = [
    { age: "" },
    { age: 0 },
    { age: 3 },
    { age: 12 },
    { age: 13 }
];

// Create a BrixxDecisionTable instance
const table = new BrixxDecisionTable({ file: "./brixx_check_age.json" });            

// Check the decision table input data list
input_data.map((input) => {
    // Get the output from decision table input data
    const output = table.check(input)
    // Prints the output to console
    console.log(output)
});

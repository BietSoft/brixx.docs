// Set an animal list
const animals = ['Dog', 'Cat', 'Mouse']

// Create a Brixx default element
Brixx.element = (
  <div>
    <h2>Animals</h2>
    <ul>
      {animals.map((animal) => (
        <li>
          <h3>{animal}</h3>
        </li>
      ))}
    </ul>
  </div>
)

// Register the Brixx HTML-Element <brixx-animal-list>
Brixx.registerElement({ name: 'brixx-animal-list' })

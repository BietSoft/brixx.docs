// Imports
import { Brixx } from '@brixx/script'

// Create a Brixx JSX element
const Greeting = ({ name }) => (
  <div>
    <h3>Hello {name}. Welcome to the our Brixx world!</h3>
  </div>
)

// Create a Brixx default element
Brixx.element = (
  <div>
    <hr />
    <h2>Brixx JSX element</h2>
    <Greeting name={'Bob the Builder'} />
    <hr />
  </div>
)

// Register the Brixx HTML-Element <brixx-simple-element>
Brixx.registerElement({ name: 'brixx-simple-element' })

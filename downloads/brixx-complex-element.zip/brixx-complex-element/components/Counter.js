// Imports
import { Brixx } from '@brixx/script'

/**
 * Class Brixx Counter component
 */
export default class Counter extends Brixx.Component {
  /**
   * Create a Brixx Counter component object
   *
   * @param {*} props - the Counter props
   */
  constructor(props) {
    super(props)
    this.state = {
      count: 0
    }
  }

  /**
   * Brixx Counter component mounted
   */
  componentDidMount() {
    Brixx.console.log('Brixx Counter Component mounted')

    // Force render if component is mounted
    this.forceUpdate()
  }

  /**
   * Render the Brixx Counter component
   */
  render() {
    return (
      <div id={this.id}>
        {this.props.children}
        <h3>Count: {this.state.count}</h3>
        <button
          onClick={(event) => {
            this.setState({
              count: this.state.count + 1
            })
          }}
        >
          Increment
        </button>
      </div>
    )
  }
}

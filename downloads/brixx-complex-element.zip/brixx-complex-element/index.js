// Imports
import { Brixx } from '@brixx/script'
import Counter from './components/Counter'

// Styles
import './styles/bootstrap.min.css'
import './styles/index.css'

// Create a Brixx JSX-Element
const Greeting = ({ name }) => (
  <div>
    <h3>Hello {name}. Welcome to the our Brixx world!</h3>
  </div>
)

// Create a Brixx default element
Brixx.element = (
  <div>
    <hr />
    <h2>Brixx JSX-Element</h2>
    <Greeting name={'Bob the Builder'} />
    <hr />
    <h2>Brixx Component</h2>
    <Counter></Counter>
    <hr />
  </div>
)

// Register the Brixx HTML-Element <brixx-complex-element>
Brixx.registerElement({ name: 'brixx-complex-element' })
